export const environment = {
  production: true,
  firebase : {
    apiKey: "AIzaSyDeK6DT0wHNdFsv8Amoj6R-ncnKbLGjNjA",
    authDomain: "minisafeway-86425.firebaseapp.com",
    databaseURL: "https://minisafeway-86425.firebaseio.com",
    projectId: "minisafeway-86425",
    storageBucket: "minisafeway-86425.appspot.com",
    messagingSenderId: "1003937152084"
  }
};
