export interface AppUser{
    name: string;
    email: string;
    address: string;  
    isAdmin: boolean;
    profile_picture: string;
}